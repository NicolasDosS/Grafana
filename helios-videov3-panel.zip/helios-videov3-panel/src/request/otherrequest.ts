export class OtherRequest {

    /**
     * Method to get the uid of the current dashboard
     * @returns Uid of current Dashboard
     */
    static GetDashboardUid() {
        let url = window.location.href;
        let urlsplited = url.split("/");
        let UidDashboard = urlsplited[4];

        return UidDashboard;
    }
}
