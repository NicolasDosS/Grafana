import React, { useRef } from 'react';
import { PanelProps } from '@grafana/data';
import { SimpleOptions } from 'types';
import { OtherRequest } from '../request/otherrequest';


interface Props extends PanelProps<SimpleOptions> { }


export const VideoPanel: React.FC<Props> = () => {

    const videos = useRef<HTMLVideoElement>(null);

    let DeviceID = localStorage.getItem("ISVIDEOVALUE" + OtherRequest.GetDashboardUid());
    const DisplayVideo: any = () => {
        navigator.mediaDevices.getUserMedia({ audio: true, video: { "deviceId": DeviceID! } })
            .then((mediaStream) => {
                if (videos.current !== null) {
                    videos.current.srcObject = mediaStream;
                    videos.current.onloadedmetadata = function (e: any) {
                        if (videos.current !== null) {
                            videos.current.play();
                        }
                    }
                };
            });
    }
    DisplayVideo();
    
    return (
        <>
            <video ref={videos} autoPlay ></video>
        </>
    );
};

